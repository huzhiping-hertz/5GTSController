# ReadMe.txt for Update32
# 2017-02-02 Muegge 

old Update32 Installer "setup.exe" V03.54 with WinPcap V4.1.2 
has been  replaced by 
"Update32Install.exe" with Helpfile upd32.chm and  WinPcap V4.1.3 
 

